-- CreateTable
CREATE TABLE "Settings" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "appName" TEXT NOT NULL DEFAULT 'Wistlist App',
    "appDescription" TEXT DEFAULT 'Wistlist App Description'
);
